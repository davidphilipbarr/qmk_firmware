# Jarred's CRKBD Layout

Check out [user space readme](../../../../users/jarred/readme.md) for more info

# Build

```
make crkbd:jarred:avrdude
```
