# Reade.md for what I want from my HeliDox(CRKBD) layout
======================================================


![My beloved HeliDox keeb](https://i.imgur.com/NbVAB3g.jpg)

- media keys and media controls
- in-switch LED intensity controls (+/-)
- underglow RGB hue/color controls
- underglow RGB intensity controls
- familiar key arrangement with Enter and symbols on the usual keys (to the right hand side)
- navigation keys should be the vim ones really;
- arrow keys on one layer(most likely on the ADJUST one)

See keymap.c for layouts


P.S> this lil' keeb is so addictive I have no words, really...
